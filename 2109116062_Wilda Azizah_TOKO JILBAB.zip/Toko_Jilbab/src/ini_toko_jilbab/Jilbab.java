package ini_toko_jilbab;

import java.sql.SQLException;

import dt_base.inidatabase;

public class Jilbab extends inidatabase{
    public Jilbab() throws ClassNotFoundException, SQLException {
        super();
    }
    
    public void jilbabupdate(String id, String nama, String harga) throws SQLException {
        String sql = String.format("UPDATE Jilbab SET id = '%s' , nama = '%s', harga = '%s' "
                + "WHERE nama = '%s', harga'%$'",
                id, nama, harga);
        this.setQuery(sql);
        this.execute();
    }

    // Delete
    public void hapusjilbab (String nama) throws SQLException {
        String sql = String.format("DELETE FROM Jilbab WHERE nama  = '%s'", nama);
        this.execute();
    }

    // Validation untuk mencegah redudansi data
    public boolean cekjilbab(String nama) throws SQLException {
        alljilbab();
        while (this.value.next()) {
            if (this.value.getString("Jilbab") == nama) {
                return false;
            }
        }
        return true;
    }
    public int lenJilbab() throws SQLException {
        alljilbab();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
    
    public void tambahjilbab(String id, String nama, String harga) throws SQLException {
        String sql = String.format("INSERT INTO suster (id, nama, harga) VALUE "
                + "('%s', '%s', '%s', '%s')", id, nama, harga);
        this.setQuery(sql);
        this.execute();
    }

    public void alljilbab() throws SQLException {
        String sql = "SELECT * FROM Jilbab";
        this.setQuery(sql);
        this.fetch();
    }
  
    public String[][] tampiljilbab() throws SQLException {
        String[][] jlbb = new String[this.lenJilbab()][4];
        alljilbab();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            jlbb[i][0] = this.value.getString("id");
            jlbb[i][1] = this.value.getString("nama");
            jlbb[i][2] = this.value.getString("harga");
            i++;
        }
        return jlbb;
    }
    
}
