package ini_toko_jilbab;

import java.sql.SQLException;
import javax.swing.*;

import dt_base.inidatabase;

public class Akun extends inidatabase {
    public Akun() throws ClassNotFoundException, SQLException {
        super();
    }

    public boolean authentication(String username, String password) throws SQLException {
        String sql = String.format("SELECT * FROM user WHERE username = '%s' AND password = '%s'", username, password);
        this.setQuery(sql);
        this.fetch();
        
        while(this.value.next()) {
            if(this.value.getString("username") != null) {
                return true;
            }
        }
        
        return false;
    }

    public boolean validation(String username) {
        return true;
    }

    public void logout() {
        
    }
}
