package GUI_toko_jilbab;

import ini_toko_jilbab.Jilbab;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class TambahJilbab extends javax.swing.JFrame {
    Jilbab j;

    public TambahJilbab() throws ClassNotFoundException, SQLException {
        j = new Jilbab();
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        idjilbab = new javax.swing.JTextField();
        nama = new javax.swing.JTextField();
        harga = new javax.swing.JTextField();
        tambahjilbab = new javax.swing.JButton();
        kembali = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        idjilbab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idjilbabActionPerformed(evt);
            }
        });
        getContentPane().add(idjilbab);
        idjilbab.setBounds(120, 120, 200, 22);

        nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namaActionPerformed(evt);
            }
        });
        getContentPane().add(nama);
        nama.setBounds(120, 170, 200, 22);

        harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hargaActionPerformed(evt);
            }
        });
        getContentPane().add(harga);
        harga.setBounds(120, 220, 200, 22);

        tambahjilbab.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        tambahjilbab.setForeground(new java.awt.Color(204, 0, 0));
        tambahjilbab.setText("Tambah");
        tambahjilbab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tambahjilbabMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tambahjilbabMouseEntered(evt);
            }
        });
        tambahjilbab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahjilbabActionPerformed(evt);
            }
        });
        getContentPane().add(tambahjilbab);
        tambahjilbab.setBounds(40, 290, 92, 28);

        kembali.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        kembali.setForeground(new java.awt.Color(204, 0, 0));
        kembali.setText("Cancel");
        kembali.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kembaliMouseClicked(evt);
            }
        });
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(kembali);
        kembali.setBounds(150, 290, 92, 28);

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("Id");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(70, 110, 30, 40);

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 0));
        jLabel3.setText("Nama");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(70, 160, 120, 40);

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 51, 0));
        jLabel4.setText("Harga");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(70, 210, 150, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/bg.png"))); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 0, 390, 390);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void idjilbabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idjilbabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idjilbabActionPerformed

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembaliActionPerformed

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namaActionPerformed

    private void hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hargaActionPerformed

    private void tambahjilbabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahjilbabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tambahjilbabActionPerformed

    private void tambahjilbabMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahjilbabMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_tambahjilbabMouseEntered

    private void tambahjilbabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahjilbabMouseClicked
        try {   
            String idj = idjilbab.getText();
            String nm = nama.getText();
            String hr = harga.getText();
 
            try {
                j.tambahjilbab(idj, nm, hr);
            } catch (SQLException ex) {
                Logger.getLogger(TambahJilbab.class.getName()).log(Level.SEVERE, null, ex);
            }

            JOptionPane.showMessageDialog(null, "TAMBAH DATA BERHASIL");

            try {
                new  IniDataJilbab().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TambahJilbab.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TambahJilbab.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "TAMBAH DATA GAGAL");
            try {
                new TambahJilbab().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TambahJilbab.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TambahJilbab.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        }
    }//GEN-LAST:event_tambahjilbabMouseClicked

    private void kembaliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kembaliMouseClicked
        try {
           IniDataJilbab idj = new  IniDataJilbab();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
        try {
            new  IniDataJilbab().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TambahJilbab.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TambahJilbab.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_kembaliMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField harga;
    private javax.swing.JTextField idjilbab;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JButton kembali;
    private javax.swing.JTextField nama;
    private javax.swing.JButton tambahjilbab;
    // End of variables declaration//GEN-END:variables
}
