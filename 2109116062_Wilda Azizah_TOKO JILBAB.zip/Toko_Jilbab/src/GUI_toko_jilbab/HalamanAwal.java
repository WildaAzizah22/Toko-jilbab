package GUI_toko_jilbab;

import java.sql.SQLException;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class HalamanAwal extends javax.swing.JFrame {

    public HalamanAwal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Datajilbab = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        Datajilbab.setFont(new java.awt.Font("Century Schoolbook", 0, 10)); // NOI18N
        Datajilbab.setForeground(new java.awt.Color(204, 0, 0));
        Datajilbab.setText("Mulai");
        Datajilbab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DatajilbabMouseClicked(evt);
            }
        });
        Datajilbab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DatajilbabActionPerformed(evt);
            }
        });
        getContentPane().add(Datajilbab);
        Datajilbab.setBounds(30, 330, 80, 30);

        jToggleButton1.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        jToggleButton1.setForeground(new java.awt.Color(204, 0, 0));
        jToggleButton1.setText("LOGOUT");
        jToggleButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jToggleButton1MouseClicked(evt);
            }
        });
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jToggleButton1);
        jToggleButton1.setBounds(250, 330, 120, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Halaman awal_1.png"))); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 0, 390, 400);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DatajilbabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DatajilbabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DatajilbabActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void DatajilbabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DatajilbabMouseClicked
        try {
            new IniDataJilbab().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(HalamanAwal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(HalamanAwal.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
        
    }//GEN-LAST:event_DatajilbabMouseClicked

    private void jToggleButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jToggleButton1MouseClicked
        JOptionPane.showMessageDialog(null, "ANDA AKAN LOGOUT");
        try {
            new Login().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(HalamanAwal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(HalamanAwal.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_jToggleButton1MouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Datajilbab;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables
}
