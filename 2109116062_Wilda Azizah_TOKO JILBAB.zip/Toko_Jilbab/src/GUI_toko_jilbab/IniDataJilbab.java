package GUI_toko_jilbab;
import javax.swing.*;
import ini_toko_jilbab.Jilbab;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IniDataJilbab extends javax.swing.JFrame {
    Jilbab j;

    public IniDataJilbab() throws ClassNotFoundException, SQLException {
        j = new Jilbab();
        initComponents();
        this.showData();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        tambahjilbab = new javax.swing.JButton();
        ubahjilbab = new javax.swing.JButton();
        back = new javax.swing.JButton();
        hapusjilbab = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabeljilbab = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        tambahjilbab.setForeground(new java.awt.Color(204, 0, 0));
        tambahjilbab.setText("Add");
        tambahjilbab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tambahjilbabMouseClicked(evt);
            }
        });
        tambahjilbab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahjilbabActionPerformed(evt);
            }
        });
        getContentPane().add(tambahjilbab);
        tambahjilbab.setBounds(170, 100, 80, 20);

        ubahjilbab.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        ubahjilbab.setForeground(new java.awt.Color(204, 51, 0));
        ubahjilbab.setText("Update");
        ubahjilbab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ubahjilbabMouseClicked(evt);
            }
        });
        ubahjilbab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ubahjilbabActionPerformed(evt);
            }
        });
        getContentPane().add(ubahjilbab);
        ubahjilbab.setBounds(270, 100, 80, 22);

        back.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        back.setForeground(new java.awt.Color(204, 0, 0));
        back.setText("Back");
        back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backMouseClicked(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(60, 320, 80, 22);

        hapusjilbab.setForeground(new java.awt.Color(204, 0, 0));
        hapusjilbab.setText("Delete");
        hapusjilbab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hapusjilbabMouseClicked(evt);
            }
        });
        hapusjilbab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusjilbabActionPerformed(evt);
            }
        });
        getContentPane().add(hapusjilbab);
        hapusjilbab.setBounds(60, 100, 80, 20);

        tabeljilbab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "id", "nama", "harga"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabeljilbab);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(60, 140, 290, 140);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/bg.png"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 400, 400);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tambahjilbabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahjilbabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tambahjilbabActionPerformed

    private void tambahjilbabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahjilbabMouseClicked
        try {
            new TambahJilbab().setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_tambahjilbabMouseClicked

    private void hapusjilbabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hapusjilbabMouseClicked
        try{ 
            String nama = JOptionPane.showInputDialog("Masukan Nama : ", null); 
            if (nama == null) { 
                try { 
                    new IniDataJilbab().setVisible(true); 
                } catch (ClassNotFoundException ex) { 
                    Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex); 
                } catch (SQLException ex) { 
                    Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                this.dispose(); 
            } else { 
                try { 
                    j.hapusjilbab(nama); 
                } catch (SQLException ex) { 
                    Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                try { 
                    this.showData(); 
                } catch (SQLException e) { 
                    // TODO Auto-generated catch block 
                    e.printStackTrace(); 
                } 
            } 
        } catch (Exception e) { 
            try { 
                new IniDataJilbab().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose(); 
        } 
    }//GEN-LAST:event_hapusjilbabMouseClicked

    private void backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backMouseClicked
       new HalamanAwal().setVisible(true);
       this.dispose();
    }//GEN-LAST:event_backMouseClicked

    private void ubahjilbabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ubahjilbabMouseClicked
        try{ 
            String nama = JOptionPane.showInputDialog("Masukan Nama : ", null); 
            this.dispose();
            if (nama == null) { 
                try { 
                    new IniDataJilbab().setVisible(true); 
                } catch (ClassNotFoundException ex) { 
                    Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex); 
                } catch (SQLException ex) { 
                    Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                this.dispose(); 
            } else { 
                try { 
                    new ubahdatajilbab(nama).setVisible(true); 
                } catch (SQLException ex) { 
                    Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex); 
                } 
                try { 
                    this.showData(); 
                } catch (SQLException e) { 
                    // TODO Auto-generated catch block 
                    e.printStackTrace(); 
                } 
            } 
        } catch (Exception e) { 
            try { 
                new IniDataJilbab().setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(IniDataJilbab.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose(); 
        }
    }//GEN-LAST:event_ubahjilbabMouseClicked

    private void ubahjilbabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ubahjilbabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ubahjilbabActionPerformed

    private void hapusjilbabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusjilbabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hapusjilbabActionPerformed

    public void showData() throws SQLException {
        tabeljilbab.setModel(new javax.swing.table.DefaultTableModel(
            j.tampiljilbab(),
            new String [] {
                "id", "nama", "harga"
            }
        ));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton hapusjilbab;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabeljilbab;
    private javax.swing.JButton tambahjilbab;
    private javax.swing.JButton ubahjilbab;
    // End of variables declaration//GEN-END:variables
}
