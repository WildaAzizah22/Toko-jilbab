
package GUI_toko_jilbab;


import ini_toko_jilbab.Jilbab;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class ubahdatajilbab extends javax.swing.JFrame {
    Jilbab j;
    String nama;


    public ubahdatajilbab(String nama) throws ClassNotFoundException, SQLException {
        j = new Jilbab();
        this.nama = nama;
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        id = new javax.swing.JTextField();
        name = new javax.swing.JTextField();
        update = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        iniharga = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        id.setFont(new java.awt.Font("Inter", 0, 12)); // NOI18N
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(150, 130, 160, 22);

        name.setFont(new java.awt.Font("Inter", 0, 12)); // NOI18N
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        getContentPane().add(name);
        name.setBounds(150, 180, 160, 22);

        update.setBackground(new java.awt.Color(255, 204, 204));
        update.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        update.setForeground(new java.awt.Color(102, 102, 102));
        update.setText("Update");
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                updateMouseEntered(evt);
            }
        });
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        getContentPane().add(update);
        update.setBounds(90, 280, 92, 28);

        cancel.setBackground(new java.awt.Color(255, 204, 204));
        cancel.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        cancel.setForeground(new java.awt.Color(102, 102, 102));
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        getContentPane().add(cancel);
        cancel.setBounds(210, 280, 92, 28);

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText(" Id");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(90, 130, 30, 15);

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Nama");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(90, 180, 110, 15);

        jLabel5.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        jLabel5.setText("Harga");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(90, 230, 120, 15);

        iniharga.setFont(new java.awt.Font("Inter", 0, 12)); // NOI18N
        iniharga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inihargaActionPerformed(evt);
            }
        });
        getContentPane().add(iniharga);
        iniharga.setBounds(150, 230, 160, 20);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/bg.png"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 400, 400);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
                
    }//GEN-LAST:event_cancelActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateActionPerformed

    private void updateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_updateMouseEntered

    private void updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseClicked
        try {
            
            String nm = name.getText();
            String hr = iniharga.getText();

            try {
               j.jilbabupdate(nama, nm, hr );
            } catch (SQLException ex) {
                Logger.getLogger(ubahdatajilbab.class.getName()).log(Level.SEVERE, null, ex);
            }


            JOptionPane.showMessageDialog(null, "UBAH DATA BERHASIL");

            new IniDataJilbab().setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "UBAH DATA GAGAL");
            try {
                new ubahdatajilbab(nama).setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ubahdatajilbab.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(ubahdatajilbab.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
        }
        this.dispose();
    }//GEN-LAST:event_updateMouseClicked

    private void inihargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inihargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inihargaActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancel;
    private javax.swing.JTextField id;
    private javax.swing.JTextField iniharga;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField name;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
