package dt_base;

import java.sql.*;
import GUI_toko_jilbab.Login;

public abstract class inidatabase implements ini_DBint {
    private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String url = "jdbc:mysql://localhost/toko_jilbab";
    private final String username = "root";
    private final String password = "";

    private Connection conn;
    private Statement stmt;
    protected ResultSet value;
    private String query;

    public inidatabase() throws ClassNotFoundException, SQLException {
        Class.forName(JDBC_DRIVER);
        conn = DriverManager.getConnection(url, username, password);
        stmt = conn.createStatement();
    }

    @Override
    public void setQuery(String inisql) {
        this.query = inisql;
    }

    @Override
    public String getQuery() {
        return this.query;
    }

    public void setClose() throws SQLException {
        this.stmt.close();
        conn.close();
    }

    public void execute() throws SQLException {
        stmt.execute(this.query);
    }

    public void fetch() throws SQLException {
        this.value = stmt.executeQuery(this.query);
    }
}