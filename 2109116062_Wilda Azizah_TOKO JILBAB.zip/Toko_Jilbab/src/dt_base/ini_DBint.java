
package dt_base;


public interface ini_DBint {
    public void setQuery(String sql);

    public String getQuery();
}
